package com.cg.EmpSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.EmpSystem.bean.LeaveDetail;
import com.cg.EmpSystem.dao.LeaveRepository;



/**
 * @author puchekar
 *
 */
@Service
public class LeaveDetailServiceImpl implements LeaveDetailService {

	@Autowired
	LeaveRepository leaveRepository;

	@Override
	public Boolean saveLeaveDetail(LeaveDetail leaveDetail) {
		if (leaveRepository.save(leaveDetail) != null) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public List<LeaveDetail> getAllLeaveDetail() {

		return leaveRepository.findAll();
	}

	@Override
	public LeaveDetail getLeaveDetailById(int id) {
		// TODO Auto-generated method stub
		return leaveRepository.findById(id).get();
	}

	@Override
	public void deleteLeaveDetail(int id) {
		leaveRepository.deleteById(id);
	}

}
