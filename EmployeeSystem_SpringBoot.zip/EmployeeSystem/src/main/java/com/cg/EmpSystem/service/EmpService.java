package com.cg.EmpSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.EmpSystem.bean.Emp;
import com.cg.EmpSystem.dao.IEmpDao;



/**
 * @author puchekar
 *
 */
@Service
public class EmpService{
	
	@Autowired
	IEmpDao empdao;

	public Emp addStudent(Emp student) {
		return empdao.save(student);
	}
	
	public Emp validateStudent(String username,String password) {
		  return empdao.validateStudent(username,password); 
	}
	
	public List<Emp> getAllStudents(){
		return empdao.getAllstudents();
	}

	public List<Emp> getAllAdmins(){
		return empdao.getAllAdmins();
	}
	
	public void deleteStudent(Long userId) {
		empdao.deleteById(userId);
	}
	
	
	
	
	public Emp getStudentById(Long userId) {
		return empdao.getStudentById(userId);
	}
	
	public Emp getAdminById(Long studentid) {
		return empdao.getAdminById(studentid);
	}

	/*
	 * public int updateStudent(String email, Long studentid) { return
	 * studentdao.updateStudent(email, studentid); }
	 */
	
	public Emp checkUniqueUsername(String username) {
		return empdao.checkUniqueUsername(username);
	}
	
	
	public int updateStudent(Emp emp) {
		// TODO Auto-generated method stub
		 return empdao.updateStudent(emp);
	}

}
