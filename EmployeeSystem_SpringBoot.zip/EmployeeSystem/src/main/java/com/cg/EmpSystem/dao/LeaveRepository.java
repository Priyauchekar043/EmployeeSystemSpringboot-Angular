package com.cg.EmpSystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.EmpSystem.bean.LeaveDetail;



/**
 * @author puchekar
 *
 */
@Repository
public interface LeaveRepository extends JpaRepository<LeaveDetail, Integer> {

}
