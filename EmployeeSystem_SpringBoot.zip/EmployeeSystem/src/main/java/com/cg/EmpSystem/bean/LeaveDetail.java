package com.cg.EmpSystem.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author puchekar
 *
 */
@Entity
@Table(name = "LeaveDetail")
public class LeaveDetail {
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)

	private Integer leaveId;
	@Column
	private Date date1;
	@Column
	private Date date2;
	@Column
	private int totalleave;
	@Column
	private int count;
	@Column
	private int reaminleave;
	@Column
	private String Reason;
	@Column
	private String comment;
	@Column
	private int userId;// pk

	public Date getDate1() {
		return date1;
	}

	public void setDate1(Date date1) {
		this.date1 = date1;
	}

	public Date getDate2() {
		return date2;
	}

	public void setDate2(Date date2) {
		this.date2 = date2;
	}

	public int getTotalleave() {
		return totalleave;
	}

	public void setTotalleave(int totalleave) {
		this.totalleave = totalleave;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getReaminleave() {
		return reaminleave;
	}

	public void setReaminleave(int reaminleave) {
		this.reaminleave = reaminleave;
	}

	public Integer getLeaveId() {
		return leaveId;
	}

	public void setLeaveId(Integer leaveId) {
		this.leaveId = leaveId;
	}

	public String getReason() {
		return Reason;
	}

	public void setReason(String reason) {
		Reason = reason;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "LeaveDetail [leaveId=" + leaveId + ", date1=" + date1 + ", date2=" + date2 + ", totalleave="
				+ totalleave + ", count=" + count + ", reaminleave=" + reaminleave + ", Reason=" + Reason + ", comment="
				+ comment + ", userId=" + userId + "]";
	}

	public LeaveDetail() {
		super();
	}

	public LeaveDetail(Integer leaveId, Date date1, Date date2, int totalleave, int count, int reaminleave,
			String reason, String comment, int userId) {
		super();
		this.leaveId = leaveId;
		this.date1 = date1;
		this.date2 = date2;
		this.totalleave = totalleave;
		this.count = count;
		this.reaminleave = reaminleave;
		Reason = reason;
		this.comment = comment;
		this.userId = userId;
	}

}
