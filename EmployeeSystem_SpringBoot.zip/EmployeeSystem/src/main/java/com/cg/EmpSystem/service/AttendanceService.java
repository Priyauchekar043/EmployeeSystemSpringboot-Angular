package com.cg.EmpSystem.service;

import java.util.List;

import com.cg.EmpSystem.bean.Attendance;



/**
 * @author puchekar
 *
 */
public interface AttendanceService {

	Attendance saveAttendance(Attendance attendance);

	List<Attendance> getAllAttendance();

	Attendance getAttendanceById(int id);

	void deleteAttendance(int id);

}
