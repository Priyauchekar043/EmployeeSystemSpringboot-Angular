package com.cg.EmpSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.EmpSystem.bean.Attendance;
import com.cg.EmpSystem.dao.AttRepository;



/**
 * @author puchekar
 *
 */
@Service
public class AttendanceServiceImpl implements AttendanceService {

	@Autowired
	AttRepository attRepository;

	@Override
	public Attendance saveAttendance(Attendance attendance) {
	
			return attendance != null ? attRepository.save(attendance): null;
	}

	@Override
	public List<Attendance> getAllAttendance() {

		return attRepository.findAll();
	}

	@Override
	public Attendance getAttendanceById(int id) {

		return attRepository.findById(id).get();
	}

	@Override
	public void deleteAttendance(int id) {
		// TODO Auto-generated method stub
		attRepository.deleteById(id);
	}

}
