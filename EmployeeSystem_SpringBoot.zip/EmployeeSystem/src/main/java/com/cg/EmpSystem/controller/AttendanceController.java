package com.cg.EmpSystem.controller;


import java.util.List;


import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.EmpSystem.bean.Attendance;
import com.cg.EmpSystem.bean.Emp;
import com.cg.EmpSystem.service.AttendanceService;


/**
 * @author puchekar
 *
 */
@CrossOrigin(origins = "http://localhost:4200")

@RestController
@RequestMapping(value = "/api/student")
public class AttendanceController {

	@Autowired
	AttendanceService AttendanceService;
	
	private final Logger LOG = LoggerFactory.getLogger(getClass());
	
	/**
	 * @param attendance
	 * @param session
	 * @return
	 */
	@PostMapping(value = "/save")
	public Attendance postStudent(@RequestBody Attendance attendance, HttpSession session) {
		System.out.println("attendance");
		System.out.println(attendance);

		Attendance result = new Attendance();
		if (null != attendance) {
			//Integer aId = (Integer) session.getAttribute("aAId");
			attendance.setEmpleave(2);
			attendance.setSalary(30000);
			
				try {
					//Integer userId = (Integer) session.getAttribute("userId");
					//attendance.setUserId(userId);
					result = AttendanceService.saveAttendance(attendance);
					LOG.info("Saving Attendance Details...");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		
		return result;
	}

	

	/**
	 * @return
	 */
	@GetMapping(value = "/getAll")
	public  List<Attendance> getAllAttendance() {
		List<Attendance> allAttendance = AttendanceService.getAllAttendance();
		LOG.info("Getting all attendance list...");
		return allAttendance;
	}

	/**
	 * @param aId
	 * @return
	 */
	@GetMapping(value = "/findById/{aId}")
	public ModelAndView getByAttendanceId(@PathVariable(name = "aId") int aId) {
		Attendance ad = AttendanceService.getAttendanceById(aId);
		ModelAndView mav = new ModelAndView("index");
		return mav;
	}

	/**
	 * @param aId
	 * @return
	 */
	@GetMapping(value = "/delete/{aId}")
	public ModelAndView deleteAttendance(@PathVariable(name = "aId") int aId) {
		AttendanceService.deleteAttendance(aId);
		ModelAndView mav = new ModelAndView("index");
		return mav;
	}

}
