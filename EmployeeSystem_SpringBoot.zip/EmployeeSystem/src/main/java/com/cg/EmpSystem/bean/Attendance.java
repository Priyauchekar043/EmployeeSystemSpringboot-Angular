package com.cg.EmpSystem.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author puchekar
 *
 */
@Entity
@Table(name = "Attendance")
public class Attendance {
	@Column
	private Integer userId;// Fk
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer aId;// PK
	@Column
	private String date;
	// private Date date;
	@Column
	private Integer attenddays;
	@Column
	private Integer empleave;
	@Column
	private Integer totalattenddays;
	@Column
	private Integer salary;

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getaId() {
		return aId;
	}

	public void setaId(Integer aId) {
		this.aId = aId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Integer getAttenddays() {
		return attenddays;
	}

	public void setAttenddays(Integer attenddays) {
		this.attenddays = attenddays;
	}

	public Integer getEmpleave() {
		return empleave;
	}

	public void setEmpleave(Integer empleave) {
		this.empleave = empleave;
	}

	public Integer getTotalattenddays() {
		return totalattenddays;
	}

	public void setTotalattenddays(Integer totalattenddays) {
		this.totalattenddays = totalattenddays;
	}

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Attendance [userId=" + userId + ", aId=" + aId + ", date=" + date + ", attenddays=" + attenddays
				+ ", empleave=" + empleave + ", totalattenddays=" + totalattenddays + ", salary=" + salary + "]";
	}

	public Attendance() {
		super();
	}

	public Attendance(Integer userId, Integer aId, String date, Integer attenddays, Integer empleave,
			Integer totalattenddays, Integer salary) {
		super();
		this.userId = userId;
		this.aId = aId;
		this.date = date;
		this.attenddays = attenddays;
		this.empleave = empleave;
		this.totalattenddays = totalattenddays;
		this.salary = salary;
	}

}