package com.cg.EmpSystem.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.EmpSystem.bean.LeaveDetail;
import com.cg.EmpSystem.service.LeaveDetailService;



/**
 * @author puchekar
 *
 */
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/student")
public class LeaveController {
	@Autowired
	LeaveDetailService leaveDetailService;

	
	
	/**
	 * @param leaveDetail
	 * @param model
	 * @param session
	 * @return
	 */
	@PostMapping(value = "/saveleave")
	public ModelAndView saveLeaveDetail(@ModelAttribute("model") LeaveDetail leaveDetail, Model model,
			HttpSession session) {
		Integer leaveId = (Integer) session.getAttribute("aLeaveId");
		leaveDetail.setTotalleave(2);
		leaveDetail.setReaminleave(0);

		if (leaveId == null) {
			try {

				Integer userId = (Integer) session.getAttribute("userId");
				leaveDetail.setUserId(userId);// FK ; logged in userId
				leaveDetail.setReaminleave(leaveDetail.getTotalleave() - leaveDetail.getCount());
				Boolean result = leaveDetailService.saveLeaveDetail(leaveDetail);
				if (result == true) {
					model.addAttribute("leavemsg", "Leave apply successfully");
					return new ModelAndView("applyleave");
				} else {
					model.addAttribute("leavemsg", "Leave apply failed");
					return new ModelAndView("applyleave");
				}

			} catch (Exception e) {
				e.printStackTrace();
				model.addAttribute("leavemsg", "Leave apply failed");
				return new ModelAndView("applyleave");
			}

		}
		return new ModelAndView("applyleave");

	}

	/**
	 * @return
	 */
	@GetMapping(value = "/getAllleave")
	public ModelAndView getAllLeaveDetail() {
		List<LeaveDetail> allLeaveDetail = leaveDetailService.getAllLeaveDetail();
		ModelAndView mav = new ModelAndView("index");
		return mav;
	}

	/**
	 * @param leaveId
	 * @return
	 */
	@GetMapping(value = "/findById/{leaveId}")
	public ModelAndView getByLeaveDetailId(@PathVariable(name = "leaveId") int leaveId) {
		LeaveDetail ad = leaveDetailService.getLeaveDetailById(leaveId);
		ModelAndView mav = new ModelAndView("index");
		return mav;
	}

	/**
	 * @param leaveId
	 * @return
	 */
	@GetMapping(value = "/delete/{id}")
	public ModelAndView deleteLeaveDetail(@PathVariable(name = "leaveId") int leaveId) {
		leaveDetailService.deleteLeaveDetail(leaveId);
		ModelAndView mav = new ModelAndView("index");
		return mav;
	}

}
