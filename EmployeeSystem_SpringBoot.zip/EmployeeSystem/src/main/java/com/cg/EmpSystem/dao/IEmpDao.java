package com.cg.EmpSystem.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.EmpSystem.bean.Emp;


/**
 * @author puchekar
 *
 */
@Repository
public interface IEmpDao extends JpaRepository<Emp, Long>{
	
	/**
	 * @param username
	 * @param password
	 * @return
	 */
	@Query(value = "SELECT * FROM Employee s WHERE s.username = ?1 AND s.password = ?2",nativeQuery = true)
	public Emp validateStudent(String username,String password);
	
	/**
	 * @param username
	 * @return
	 */
	@Query(value = "SELECT * FROM Employee s WHERE s.username = ?1",nativeQuery = true)
	public Emp checkUniqueUsername(String username);
	
	/*
	 * @Transactional
	 * 
	 * @Query(value =
	 * "UPDATE Employee s SET s.email = ?1 where s.userId = ?2",nativeQuery = true)
	 * 
	 * @Modifying public int updateStudent(String email, Long userId);
	 */
	
	/**
	 * @return
	 */
	@Query(value = "SELECT * FROM Employee s WHERE s.role = 'Emp'",nativeQuery = true)
	public List<Emp> getAllstudents();
	
	/**
	 * @return
	 */
	@Query(value = "SELECT * FROM Employee s WHERE s.role = 'Admin'",nativeQuery = true)
	public List<Emp> getAllAdmins();
	
	/**
	 * @param userId
	 * @return
	 */
	@Query(value = "SELECT * FROM Employee s WHERE s.user_Id = ?1 AND s.role='Emp' ",nativeQuery = true)
	public Emp getStudentById(Long userId);
	
	/**
	 * @param userId
	 * @return
	 */
	@Query(value = "SELECT * FROM Employee s WHERE s.user_Id = ?1 AND s.role='Admin' ",nativeQuery = true)
	public Emp getAdminById(Long userId);
	
	
	
	 /**
	 * @param emp
	 * @return
	 */
	@Transactional
	  
	  @Query(value =
	  "UPDATE Employee s SET s.userId = ?1 where s.userId = ?2",nativeQuery = true)
	 
	  @Modifying 
	public int updateStudent(Emp emp);

	
}
