package com.cg.EmpSystem.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.cg.EmpSystem.bean.Emp;


import com.cg.EmpSystem.service.EmpService;


/**
 * @author puchekar
 *
 */
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/student")
public class EmpController {

	@Autowired
	private EmpService empservice;
	
	
	
	private final Logger LOG = LoggerFactory.getLogger(getClass());
	
	

	/**
	 * @param student
	 * @return
	 */
	@PostMapping(value = "/create")
	public Emp postStudent(@RequestBody Emp student) {
		student.setRole("Emp");
		Emp _student = empservice.addStudent(student);
		LOG.info("Saving Emp Details...");
		return _student;
	}
	


	/**
	 * @param username
	 * @param password
	 * @return
	 */
	@GetMapping(value = "/find")
	public Emp validateStudent(@RequestParam("username") String username,
			@RequestParam("password") String password) {
		System.out.println("username"+username);
		System.out.println("password"+password);
		Emp _student = empservice.validateStudent(username, password);
		LOG.info("Authorized User...");
		return _student;
	}
	
	/**
	 * @param userId
	 * @return
	 */
	@GetMapping(value="/getEmpDetail/{userId}") 
	public Emp getStudentById(@PathVariable("userId") Long userId) { 
		  Emp _student = empservice.getStudentById(userId);
		  LOG.info("Getting Emp details..");
		  return _student; 
	}
	 
	/**
	 * @return
	 */
	@GetMapping(value = "/getAdminList")
	public List<Emp> getAdminList() {
		List<Emp> ListAdmin = empservice.getAllAdmins();
		LOG.info("Getting all admin list...");
		return ListAdmin;
	}
	
	


		
		  /**
		 * @param userId
		 * @param emp
		 * @return
		 */
		@PutMapping(value = "/update")
		  public int updateStudent(@PathVariable("userId") Long userId, @RequestBody Emp emp) { 
			  emp.setUserId(userId);
			  int a=empservice.updateStudent(emp);
		
		  LOG.info("Updated emp details..."); return a; 
		  }
		 
	
	
	
	
	/**
	 * @return
	 */
	@GetMapping(value="/getEmpList")
	public List<Emp> getStduentList(){
		List<Emp> ListStudent = empservice.getAllStudents();
		LOG.info("Getting all students list...");
		return ListStudent;
	}
	
	/**
	 * @param student
	 * @return
	 */
	@PostMapping(value = "/addAdmin")
	public Emp postAdmin(@RequestBody Emp student) {
		student.setRole("Admin");
		Emp _student = empservice.addStudent(student);
		LOG.info("Admin added successfull...");
		return _student;
	}
	
	/**
	 * @param userId
	 * @return
	 */
	@DeleteMapping(value="/deleteAdmin/{userId}") 
	public boolean deleteAdmin(@PathVariable("userId") Long userId) { 
		Emp _student = empservice.getAdminById(userId);
		empservice.deleteStudent(_student.getUserId());
		LOG.info("Deleted Admin successfull...");
		return true;
	}
	
	/**
	 * @param userId
	 * @return
	 */
	@DeleteMapping(value="/deleteEmp/{userId}") 
	public boolean deleteStudent(@PathVariable("userId") Long userId) { 
		Emp _student = empservice.getStudentById(userId);
		empservice.deleteStudent(_student.getUserId());
		LOG.info("Deleted student successfully...");
		return true;
	}
	
	
	
	
	
	
}
