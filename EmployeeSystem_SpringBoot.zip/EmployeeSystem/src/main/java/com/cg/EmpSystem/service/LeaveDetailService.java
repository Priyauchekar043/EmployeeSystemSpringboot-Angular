package com.cg.EmpSystem.service;

import java.util.List;

import com.cg.EmpSystem.bean.LeaveDetail;



/**
 * @author puchekar
 *
 */
public interface LeaveDetailService {

	Boolean saveLeaveDetail(LeaveDetail leaveDetail);

	List<LeaveDetail> getAllLeaveDetail();

	LeaveDetail getLeaveDetailById(int id);

	void deleteLeaveDetail(int id);

}
