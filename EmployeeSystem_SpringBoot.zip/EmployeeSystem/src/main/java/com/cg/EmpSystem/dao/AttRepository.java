package com.cg.EmpSystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.EmpSystem.bean.Attendance;



/**
 * @author puchekar
 *
 */
@Repository
public interface AttRepository extends JpaRepository<Attendance, Integer> {

}
